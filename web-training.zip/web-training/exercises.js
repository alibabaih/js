/**
 * Return number of days to New Year from given date
 * @param d Date object
 */
function daysUntilNewYear(d) {
    // TODO Not implemented yet
}

/**
 * Reverse the string
 * @param string string to reverse
 */
function reverse(string) {
    // TODO Not implemented yet
}

/**
 * Check if object has a given property which contains number
 * Note: Both arguments can be not defined.
 * Return either the number or null
 * @param obj object to check
 * @param prop property name to check
 */
function containsNumber(obj, prop) {
    // TODO Not implemented yet
}

/**
 * Serialize the object into string in .properties format
 * http://en.wikipedia.org/wiki/.properties
 * Note: string values aren't wrapped with quotes in result
 *
 * Example: {a: '1'} becomes 'a=1'
 *
 * @param obj object to serialize
 */
function serialize(obj) {
    // TODO Not implemented yet
}

