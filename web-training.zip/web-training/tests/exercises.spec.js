var expect = chai.expect;
describe('Exercises I-1', function() {
    'use strict';
    it('should return number of days until New Year', function() {
        expect(daysUntilNewYear(new Date(2014, 12, 1))).to.equal(30);
    });

    it('should reverse the string', function() {
        expect(reverse('123abcABC')).to.equal('CBAcba321');
    });
    
    it('should check if object contains number', function() {
        expect(containsNumber(null, null)).to.be.null();
        expect(containsNumber({}, null)).to.be.null();
        expect(containsNumber({a: '1'}, null)).to.be.null();
        expect(containsNumber({a: 1}, null)).to.be.null();
        expect(containsNumber({a: 1}, 'a')).to.equal(1);
    });
    
    it('should serialize an object into .properties format', function() {
        expect(serialize({})).to.equal('');
        expect(serialize({a: 1})).to.equal('a=1');
        expect(serialize({o: {a: 1, b: 2}, c : 'a'})).to.equal('o.a=1\no.b=2\nc=a');
    });
});

